Brick Buster catalogue and ownership data

35 distinct set models; 38 owned copies.
Confirmed extra copies: 21152-1 has quantity 2; 31058-1 has quantity 3.
Every other listed model has quantity 1. No other set models are included.

Contents: themes.csv, colors.csv, parts.csv, sets.csv, minifigs.csv,
inventories.csv, inventory_parts.csv, inventory_minifigs.csv,
inventory_sets.csv, owned_sets.csv.

Extract the ZIP first. In Brick Buster, choose Import Rebrickable data,
then select this owned_sets folder containing the CSV files.
The app expects the American spelling colors.csv.
inventory_sets.csv intentionally has only a header: these selected sets
have no nested-set rows in the supplied source data.

The nine catalogue files are filtered from the supplied Rebrickable data.
sets.csv, minifigs.csv and inventory_parts.csv contain source image URLs.
Images need internet on first use; unavailable source images have blank URLs.

IMPORTANT: The current application imports only the nine catalogue CSVs.
It does not read owned_sets.csv automatically. Use My collection to enter
the confirmed quantities, or add a separate ownership-import feature.
Do not duplicate rows in sets.csv to represent additional owned copies.
